import template from './sw-cms-block-preview-owy-awards-widget.html.twig';
import './sw-cms-block-preview-owy-awards-widget.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-preview-owy-awards-widget', {
    template
});
