import './extension/sw-cms/elements/product-listing/config';
import './module/sw-cms/blocks/text-image/owy-category-tree-teaser';
import './module/sw-cms/elements/owy-category-tree-teaser';
import './module/sw-cms/blocks/text-image/owy-main-slider';
import './module/sw-cms/elements/owy-main-slider';
import './module/sw-cms/blocks/text-image/owy-awards-widget';
import './module/sw-cms/elements/owy-awards-widget';
import './module/sw-cms/blocks/text-image/owy-faq-widget';
import './module/sw-cms/elements/owy-faq-widget';
import './module/sw-cms/blocks/text-image/owy-organization-widget';
import './module/sw-cms/elements/owy-organization-widget';
import './module/sw-cms/blocks/text-image/owy-broucher-widget';
import './module/sw-cms/elements/owy-broucher-widget';
import './module/sw-cms/blocks/text-image/owy-switch-cmspage';
import './module/sw-cms/elements/owy-switch-cmspage';
import './module/sw-cms/blocks/text-image/owy-shoppage-nav';
import './module/sw-cms/elements/owy-shoppage-nav';
import './module/sw-cms/blocks/text-image/owy-editor';
import './module/sw-cms/elements/owy-editor';

import './module/sw-cms/blocks/text-image/owy-news-widget';
import './module/sw-cms/elements/owy-news-widget';
import './module/sw-cms/blocks/text-image/owy-news-detail-widget';
import './module/sw-cms/elements/owy-news-detail-widget';

import './module/sw-cms/blocks/text-image/owy-custom-form-widget';
import './module/sw-cms/elements/owy-custom-form-widget';


import deDE from './module/sw-cms/snippet/de-DE.json';
import enGB from './module/sw-cms/snippet/en-GB.json';


Shopware.Locale.extend('de-DE', deDE);
Shopware.Locale.extend('de-DE', enGB);