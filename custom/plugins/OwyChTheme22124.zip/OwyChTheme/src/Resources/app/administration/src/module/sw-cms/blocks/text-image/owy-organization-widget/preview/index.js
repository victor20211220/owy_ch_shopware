import template from './sw-cms-block-preview-owy-organization-widget.html.twig';
import './sw-cms-block-preview-owy-organization-widget.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-preview-owy-organization-widget', {
    template
});
