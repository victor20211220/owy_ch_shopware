import template from './sw-cms-block-preview-owy-switch-cmspage.html.twig';
import './sw-cms-block-preview-owy-switch-cmspage.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-preview-owy-switch-cmspage', {
    template
});
