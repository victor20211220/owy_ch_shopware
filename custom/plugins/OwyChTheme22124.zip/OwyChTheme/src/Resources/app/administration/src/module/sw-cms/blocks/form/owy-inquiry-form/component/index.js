import template from './sw-cms-block-owy-inquiry-form.html.twig';
import './sw-cms-block-owy-inquiry-form.scss';

Shopware.Component.register('sw-cms-block-owy-inquiry-form', {
    template
});