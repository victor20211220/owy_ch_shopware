import template from './sw-cms-block-owy-editor.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-owy-editor', {
    template
});
