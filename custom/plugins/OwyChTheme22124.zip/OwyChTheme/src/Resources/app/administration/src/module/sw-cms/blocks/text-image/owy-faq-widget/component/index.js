import template from './sw-cms-block-owy-faq-widget.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-owy-faq-widget', {
    template
});
