import template from './sw-cms-el-preview-owy-shoppage-nav.html.twig';
import './sw-cms-el-preview-owy-shoppage-nav.scss';

Shopware.Component.register('sw-cms-el-preview-owy-shoppage-nav', {
    template
});
