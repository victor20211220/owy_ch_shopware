import template from './sw-cms-block-owy-shoppage-nav.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-owy-shoppage-nav', {
    template
});
