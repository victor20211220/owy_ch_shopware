import template from './sw-cms-block-preview-owy-shoppage-nav.html.twig';
import './sw-cms-block-preview-owy-shoppage-nav.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-preview-owy-shoppage-nav', {
    template
});
