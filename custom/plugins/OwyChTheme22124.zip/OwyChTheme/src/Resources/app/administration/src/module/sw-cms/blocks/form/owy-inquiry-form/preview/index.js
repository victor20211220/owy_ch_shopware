import template from './sw-cms-preview-owy-inquiry-form.html.twig';


Shopware.Component.register('sw-cms-preview-owy-inquiry-form', {
    template
});
