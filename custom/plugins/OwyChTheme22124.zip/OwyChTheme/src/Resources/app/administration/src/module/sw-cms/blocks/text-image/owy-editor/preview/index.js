import template from './sw-cms-block-preview-owy-editor.html.twig';
import './sw-cms-block-preview-owy-editor.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-preview-owy-editor', {
    template
});
