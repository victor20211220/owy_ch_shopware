import template from './sw-cms-el-preview-owy-category-tree-teaser.html.twig';
import './sw-cms-el-preview-owy-category-tree-teaser.scss';

Shopware.Component.register('sw-cms-el-preview-owy-category-tree-teaser', {
    template
});
