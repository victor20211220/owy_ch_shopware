import template from './sw-cms-block-owy-main-slider.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-owy-main-slider', {
    template
});
