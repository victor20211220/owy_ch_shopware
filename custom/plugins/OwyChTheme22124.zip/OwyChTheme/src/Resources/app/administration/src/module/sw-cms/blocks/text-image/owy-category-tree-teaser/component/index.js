import template from './sw-cms-block-owy-category-tree-teaser.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-owy-category-tree-teaser', {
    template
});
