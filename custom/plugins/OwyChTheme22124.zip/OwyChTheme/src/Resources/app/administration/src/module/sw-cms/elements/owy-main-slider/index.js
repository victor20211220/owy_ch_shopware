import './component';
import './config';


Shopware.Service('cmsService').registerCmsElement({
    name: 'owy-main-slider',
    label: 'Main Slider',
    component: 'sw-cms-el-owy-main-slider',
    configComponent: 'sw-cms-el-config-owy-main-slider',

    defaultConfig: {
        desktopImage1: {
            required: true,
            source: 'static',
            value: null
        },
        mobileImage1: {
            required: true,
            source: 'static',
            value: null
        },
        desktopImage2: {
            source: 'static',
            value: null
        },
        mobileImage2: {
            source: 'static',
            value: null
        },
        desktopImage3: {
            source: 'static',
            value: null
        },
        mobileImage3: {
            source: 'static',
            value: null
        },
        desktopImage4: {
            source: 'static',
            value: null
        },
        mobileImage4: {
            source: 'static',
            value: null
        },
        desktopImage5: {
            source: 'static',
            value: null
        },
        mobileImage5: {
            source: 'static',
            value: null
        },
        desktopImage6: {
            source: 'static',
            value: null
        },
        mobileImage6: {
            source: 'static',
            value: null
        },
        desktopImage7: {
            source: 'static',
            value: null
        },
        mobileImage7: {
            source: 'static',
            value: null
        },
        desktopImage8: {
            source: 'static',
            value: null
        },
        mobileImage8: {
            source: 'static',
            value: null
        },
        desktopImage9: {
            source: 'static',
            value: null
        },
        mobileImage9: {
            source: 'static',
            value: null
        },
        desktopImage10: {
            source: 'static',
            value: null
        },
        mobileImage10: {
            source: 'static',
            value: null
        }

    }
});
