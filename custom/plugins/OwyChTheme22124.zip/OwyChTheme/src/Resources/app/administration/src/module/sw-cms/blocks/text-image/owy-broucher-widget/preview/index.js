import template from './sw-cms-block-preview-owy-broucher-widget.html.twig';
import './sw-cms-block-preview-owy-broucher-widget.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-preview-owy-broucher-widget', {
    template
});
