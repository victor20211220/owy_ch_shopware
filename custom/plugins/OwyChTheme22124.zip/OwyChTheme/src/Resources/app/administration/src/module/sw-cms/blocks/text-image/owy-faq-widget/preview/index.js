import template from './sw-cms-block-preview-owy-faq-widget.html.twig';
import './sw-cms-block-preview-owy-faq-widget.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-preview-owy-faq-widget', {
    template
});
