import './component';
import './config';


Shopware.Service('cmsService').registerCmsElement({
    name: 'owy-awards-widget',
    label: 'Awards Widget',
    component: 'sw-cms-el-owy-awards-widget',
    configComponent: 'sw-cms-el-config-owy-awards-widget',

    defaultConfig: {
        generalheading : {
            required: true,
            source: 'static',
            value: ''
        },
        award1image1 : {
            required: true,
            source: 'static',
            value: ''
        },
        award1title1 : {
            source: 'static',
            value: ''
        },
        award1desc : {
            source: 'static',
            value: ''
        },
        award1image2 : {
            source: 'static',
            value: ''
        },
        award1title3 : {
            source: 'static',
            value: ''
        },
        award1title4 : {
            source: 'static',
            value: ''
        },

        award2image1 : {

            source: 'static',
            value: ''
        },
        award2title1 : {
            source: 'static',
            value: ''
        },
        award2desc : {
            source: 'static',
            value: ''
        },
        award2image2 : {
            source: 'static',
            value: ''
        },
        award2title3 : {
            source: 'static',
            value: ''
        },
        award2title4 : {
            source: 'static',
            value: ''
        },

        award3image1 : {

            source: 'static',
            value: ''
        },
        award3title1 : {
            source: 'static',
            value: ''
        },
        award3desc : {
            source: 'static',
            value: ''
        },
        award3image2 : {
            source: 'static',
            value: ''
        },
        award3title3 : {
            source: 'static',
            value: ''
        },
        award3title4 : {
            source: 'static',
            value: ''
        },

        award4image1 : {
            source: 'static',
            value: ''
        },
        award4title1 : {
            source: 'static',
            value: ''
        },
        award4desc : {
            source: 'static',
            value: ''
        },
        award4image2 : {
            source: 'static',
            value: ''
        },
        award4title3 : {
            source: 'static',
            value: ''
        },
        award4title4 : {
            source: 'static',
            value: ''
        },

        award5image1 : {
            source: 'static',
            value: ''
        },
        award5title1 : {
            source: 'static',
            value: ''
        },
        award5desc : {
            source: 'static',
            value: ''
        },
        award5image2 : {
            source: 'static',
            value: ''
        },
        award5title3 : {
            source: 'static',
            value: ''
        },
        award5title4 : {
            source: 'static',
            value: ''
        }
    }
});
