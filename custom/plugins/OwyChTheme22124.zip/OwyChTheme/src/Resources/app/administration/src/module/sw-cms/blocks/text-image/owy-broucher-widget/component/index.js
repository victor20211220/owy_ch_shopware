import template from './sw-cms-block-owy-broucher-widget.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-owy-broucher-widget', {
    template
});
