import template from './sw-cms-block-preview-owy-category-tree-teaser.html.twig';
import './sw-cms-block-preview-owy-category-tree-teaser.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-preview-owy-category-tree-teaser', {
    template
});
