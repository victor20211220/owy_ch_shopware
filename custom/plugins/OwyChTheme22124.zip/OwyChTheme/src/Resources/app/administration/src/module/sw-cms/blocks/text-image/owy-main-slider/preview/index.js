import template from './sw-cms-block-preview-owy-main-slider.html.twig';
import './sw-cms-block-preview-owy-main-slider.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-preview-owy-main-slider', {
    template
});
