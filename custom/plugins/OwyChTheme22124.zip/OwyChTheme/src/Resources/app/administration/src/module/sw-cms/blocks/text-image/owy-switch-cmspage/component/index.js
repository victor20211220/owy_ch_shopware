import template from './sw-cms-block-owy-switch-cmspage.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-owy-switch-cmspage', {
    template
});
