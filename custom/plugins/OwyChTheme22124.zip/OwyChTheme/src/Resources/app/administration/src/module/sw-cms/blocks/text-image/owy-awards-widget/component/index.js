import template from './sw-cms-block-owy-awards-widget.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-owy-awards-widget', {
    template
});
