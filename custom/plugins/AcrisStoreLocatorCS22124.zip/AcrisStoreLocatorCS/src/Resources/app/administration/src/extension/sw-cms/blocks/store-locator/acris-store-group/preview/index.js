import template from './sw-cms-preview-acris-store-group.html.twig';
import './sw-cms-preview-acris-store-group.scss';

const { Component } = Shopware;

Component.register('sw-cms-preview-acris-store-group', {
    template
});
