import template from './sw-cms-preview-acris-store-locator-page.html.twig';
import './sw-cms-preview-acris-store-locator-page.scss';

const { Component } = Shopware;

Component.register('sw-cms-preview-acris-store-locator-page', {
    template
});
