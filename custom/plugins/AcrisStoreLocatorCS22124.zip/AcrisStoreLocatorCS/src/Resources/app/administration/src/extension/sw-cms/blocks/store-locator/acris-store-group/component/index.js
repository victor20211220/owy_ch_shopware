import template from './sw-cms-block-acris-store-group.html.twig';
import './sw-cms-block-acris-store-group.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-acris-store-group', {
    template
});
