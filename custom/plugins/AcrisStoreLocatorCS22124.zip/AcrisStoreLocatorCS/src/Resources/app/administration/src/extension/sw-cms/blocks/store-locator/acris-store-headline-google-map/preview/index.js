import template from './sw-cms-preview-acris-store-headline-google-map.html.twig';
import './sw-cms-preview-acris-store-headline-google-map.scss';

const { Component } = Shopware;

Component.register('sw-cms-preview-acris-store-headline-google-map', {
    template
});
