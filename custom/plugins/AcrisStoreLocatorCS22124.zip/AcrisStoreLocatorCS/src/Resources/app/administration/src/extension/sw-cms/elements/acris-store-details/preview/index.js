import template from './sw-cms-el-preview-acris-store-details.html.twig';
import './sw-cms-el-preview-acris-store-details.scss';

const { Component } = Shopware;

Component.register('sw-cms-el-preview-acris-store-details', {
    template,
});
