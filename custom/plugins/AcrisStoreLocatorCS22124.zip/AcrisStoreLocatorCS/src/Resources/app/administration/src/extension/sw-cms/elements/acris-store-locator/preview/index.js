import template from './sw-cms-el-preview-acris-store-locator.html.twig';
import './sw-cms-el-preview-acris-store-locator.scss';

const { Component } = Shopware;

Component.register('sw-cms-el-preview-acris-store-locator', {
    template
});
