import template from './sw-cms-el-preview-acris-store-group.html.twig';
import './sw-cms-el-preview-acris-store-group.scss';

const { Component } = Shopware;

Component.register('sw-cms-el-preview-acris-store-group', {
    template
});
