import template from './sw-cms-block-acris-store-headline-google-map.html.twig';
import './sw-cms-block-acris-store-headline-google-map.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-acris-store-headline-google-map', {
    template
});
