import template from './sw-cms-block-acris-store-locator-page.html.twig';
import './sw-cms-block-acris-store-locator-page.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-acris-store-locator-page', {
    template
});
