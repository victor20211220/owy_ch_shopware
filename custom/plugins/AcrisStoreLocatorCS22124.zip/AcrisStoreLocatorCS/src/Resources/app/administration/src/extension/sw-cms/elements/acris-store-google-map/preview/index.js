import template from './sw-cms-el-preview-acris-store-google-map.html.twig';
import './sw-cms-el-preview-acris-store-google-map.scss';

const { Component } = Shopware;

Component.register('sw-cms-el-preview-acris-store-google-map', {
    template
});
