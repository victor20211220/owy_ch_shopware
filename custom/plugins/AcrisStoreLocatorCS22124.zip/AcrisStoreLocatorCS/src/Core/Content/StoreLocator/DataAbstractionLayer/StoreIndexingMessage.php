<?php declare(strict_types=1);

namespace Acris\StoreLocator\Core\Content\StoreLocator\DataAbstractionLayer;

use Shopware\Core\Framework\DataAbstractionLayer\Indexing\EntityIndexingMessage;

class StoreIndexingMessage extends EntityIndexingMessage
{
}
