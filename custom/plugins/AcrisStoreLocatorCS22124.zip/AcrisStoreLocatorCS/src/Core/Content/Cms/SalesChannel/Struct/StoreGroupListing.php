<?php declare(strict_types=1);

namespace Acris\StoreLocator\Core\Content\Cms\SalesChannel\Struct;

use Shopware\Core\Framework\Struct\Struct;

class StoreGroupListing extends Struct
{

}
